#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "employee.h"

void registerEmp(){
	printf("<< Register a new employee >> \n");

	printf("Final Exam1\n");
}
