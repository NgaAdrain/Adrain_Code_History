#include <stdio.h>
#include "employee.h"

void printAll(){
	printf("<<Display all employees>>\n");

	printf("Final Exam1\n");
}

