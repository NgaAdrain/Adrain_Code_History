#include <stdio.h>
#include <string.h>
#include "employee.h"

void searchByName(){
	printf("<<Search By Name>>\n");

	printf("Final Exam1\n");
}
