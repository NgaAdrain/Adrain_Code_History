#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void save(){
	printf("<<Save Max and Average>>\n");

	printf("Final Exam1\n");
}

