# Repositories for Final exam

Introduction to Open Source Software Development
Final, Spring 2019
Pusan National University
June 17th, 2019
Time Limit:  90 minutes 


*	Practice exam. 
*	Don’t forget to create a txt file whose name includes your name and student number (StudentID).
*	Please set up your computers.
