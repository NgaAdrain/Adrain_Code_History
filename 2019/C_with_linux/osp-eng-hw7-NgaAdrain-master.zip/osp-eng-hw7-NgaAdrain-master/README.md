# Open source programming HW7 @PNU

Please do the following as soon as cloning this repository.

Create “SName_Sno.txt” file at your local repository by using a touch command.

For example: SName: Joonho Kwon, Sno: 2017001 Then ==> $touch joonho_kwon_2017001.txt

//19/05/22//

Homework7 Assignment

Electric Computer Engineering Computer Major 

201524582 Jeong Hee Seok

phonebook is execute file

register.c & select.c & delete.c & makefile(modify phoneBookMain to hw7main & add sort) => same as HW6 Assignment

print.c => given codes

This time all function (excludes hw7main's main function) declared in phone.h

//19/05/24//

Modify sort.c -> complete contactCmpr with strcmp and contactSwap with memcpy.

//append report//

//0524 append report//

//============//

//if uncomfortable reading for report or find lack of report //

//I'm waiting for your feedback //

//Thanks for Checking my Assignment//
