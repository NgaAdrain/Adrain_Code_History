#ifndef _SERVICE_H_
#define _SERVICE_H_

#include "phone.h"

void registerPhoneData();//implemented in register.c
void printAll();//implemented in search.c
void searchByName();//implemented in search.c
void deleteByName();//implemented in delete.c

#endif
