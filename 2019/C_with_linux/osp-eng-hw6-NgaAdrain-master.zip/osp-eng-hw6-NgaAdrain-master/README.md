# Open Source programming HW6

Please do the following as soon as cloning this repository.

Create “SName_Sno.txt” file at your local repository by using a touch command.

For example: SName: Joonho Kwon, Sno: 2017001 
  Then ==> $touch joonho_kwon_2017001.txt

//===========================================//

//19/05/17//

Electric Computer Engineering Computer Major
201524582 Jeong Hee Seok
Homework6 Assignment
phonebook is execute file
exclude phoneBookMain.c all source code defined on service.h
all information related to phonebook, defined on phone.h

//===========================================//

//Add Report//
//Complete On 19/05/18//
