#include "inet.h"

int readline(register int fd, register char *ptr, register int maxlen);
