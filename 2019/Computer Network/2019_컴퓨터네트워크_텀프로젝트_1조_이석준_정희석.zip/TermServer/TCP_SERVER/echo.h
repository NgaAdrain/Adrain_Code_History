#include "inet.h"

#define MAXLINE 4096

void str_echo(int sockfd);
