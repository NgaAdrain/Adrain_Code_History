#include "inet.h"
#define MAXLINE 4096

void dg_cli(FILE*, int, struct sockaddr *, int);
