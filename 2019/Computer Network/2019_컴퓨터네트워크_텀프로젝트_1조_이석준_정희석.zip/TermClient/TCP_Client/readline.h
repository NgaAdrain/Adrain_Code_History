#include "inet.h"
int readline (int,char*,int);

