#include "inet.h"
#define MAXLINE 4096

void str_cli(FILE*, int);
