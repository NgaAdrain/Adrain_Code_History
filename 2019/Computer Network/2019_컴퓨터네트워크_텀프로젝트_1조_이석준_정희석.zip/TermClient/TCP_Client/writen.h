#include "inet.h"
int writen (int ,char*,int);
