﻿// Fig. 15.25: XMLDOMTraversal.html 
// Traversing an XML document using the XML DOM. 
var outputHTML = ""; // stores text to output in outputDiv
var idCounter = 1; // used to create div IDs
var depth = -1; // tree depth is -1 to start
var current = null; // represents the current node for traversals
var previous = null; // represent prior node in traversals
var tagName = "";
// register event handlers for buttons and load XML document
function start()
{
    loadXMLDocument( '201524582_JHS_ASSIGN6.xml' )
} // end function start

// load XML document programmatically
function loadXMLDocument( url )
{
   var xmlHttpRequest = new XMLHttpRequest();
   xmlHttpRequest.open( "get", url, false );
   xmlHttpRequest.send( null );
   var doc = xmlHttpRequest.responseXML;
   buildHTML( doc.childNodes ); // display the nodes
   displayDoc(); // display the document and highlight current node
} // end function loadXMLDocument

// traverse xmlDocument and build HTML5 representation of its content
function buildHTML( childList )
{
   ++depth; // increase tab depth

   // display each node's content
   for ( var i = 0; i < childList.length; i++ ) 
   {
      switch ( childList[ i ].nodeType )
      {
          case 1: // Node.ELEMENT_NODE; value used for portability
              tagName = childList[i].nodeName;
              if (childList[i].nodeName == "info") {
                  outputHTML += "<table border=\"1\">" +
                      "<caption>부산대학교</caption>" +
                      "<thead>"+
                          "<tr>"+
                      "<th colspan=\"3\">학생증</th>" +
                          "</tr>" +
                          "</thead>" +
                          "<tbody>" +
                          "<tr>" +
                          "<th rowspan=\"3\">" +
                          "<img src=\"student_example.jpg\" width=\"250\"" +
                          "height=\"400\" alt=\"Picture of student\">" +
                      "</th>";
                  buildHTML(childList[i].childNodes);
              }
              if (childList[i].nodeName == "name") {
                  outputHTML += "<th> 이름 </th>";
                  buildHTML(childList[i].childNodes);
              }
              if (childList[i].nodeName == "depart") {
                  outputHTML += "<tr>" +
                      "<th> 학과 </th>";
                  buildHTML(childList[i].childNodes);
              }
              if (childList[i].nodeName == "id") {
                  outputHTML += "<tr>" +
                      "<th> 학번 </th>";
                  buildHTML(childList[i].childNodes);
              }
            ++idCounter; // increment the id counter
            // if current node has children, call buildHTML recursively
              if (childList[i].nodeName == "info") {
                  outputHTML += "</tbody >" +
                      "<tfoot>" +
                      "<tr>" +
                      "<th colspan=\"3\">Pusan National University</th>" +
                      "</tr>" +
                      "</tfoot>" +
                      "</table >";
              }
              else if ((childList[i].nodeName == "name") ||
                       (childList[i].nodeName == "depart") ||
                       (childList[i].nodeName == "id")) {
                  outputHTML += "</tr>";
              }
            break;
          case 3: // Node.TEXT_NODE; value used for portability
              if (childList[i].nodeValue.indexOf("   ") == -1 &&
                  childList[i].nodeValue.indexOf("      ") == -1 &&
                  childList.length == 1) {
                  outputHTML += "<th> "+ childList[i].nodeValue + "</th>";
                  ++idCounter; // increment the id counter
              } // end if
          case 8: // Node.COMMENT_NODE; value used for portability
            // if nodeValue is not 3 or 6 spaces (Firefox issue),
            // include nodeValue in HTML
      } // end switch
   } // end for

   --depth; // decrease tab depth
} // end function buildHTML

// display the XML document and highlight the first child
function displayDoc()
{
   document.getElementById( "outputDiv" ).innerHTML = outputHTML;
   current = document.getElementById( "id1" ); 

} // end function displayDoc

// insert non-breaking spaces for indentation
function spaceOutput( number )
{
   for ( var i = 0; i < number; i++ )
   {
      outputHTML += "&nbsp;&nbsp;&nbsp;";
   } // end for
} // end function spaceOutput

// highlight first child of current node

window.addEventListener( "load", start, false );

/*************************************************************************
* (C) Copyright 1992-2012 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/