# Open Source programming HW9

Notice 1. For HW9, no template codes are provided. Students can implement the program from the scratch. It is alright to reuse codes from HW6, HW7 and HW8.

Notice 2. Please do the following actions as soon as cloning this repository. Create “SName_Sno.txt” file at your local repository by using a touch command. For example: SName: Joonho Kwon, Sno: 2017001 Then ==> $touch joonho_kwon_2017001.txt

//19/06/03//

Homework9 Assignment

Electric Computer Engineering Computer Major 

201524582 Jeong Hee Seok

clone hw9 and copy from codes hw8.

//19/06/03//

Create phone.dat and modify hw8Main.c to hw9Main.c and implement File I/O in register.c

Using fopen,"rb","wb" option and fread.

Create two function on register.c named registerFromFile(), writeToFile() function, 

Declare two function on phone.h

Execution Success.

Complete to modify code

//==========//
//Add Report//

//19/06/07//

Add Report and Finish This Homework!
