# Open source programming HW8 @PNU

Notice 1.For HW8, no template codes are provided. Students can implement the program from the scratch. It is alright to reuse codes from HW6 and HW7.

Notice 2. Please do the folloing actions as soon as cloning this repository. Create "SName_Sno.txt" file at your local repository by using a touch command. For example: SName: Joonho Kwon, Sno: 2017001 Then ==> $touch joonho_kwon_2017001.txt

Notice 3. Students can implement a list with either a single pointer version or a double pointer version. Please refer to the following web pages.

Double Pointers and Linked List in C https://dev-notes.eu/2018/07/double-pointers-and-linked-list-in-c/

Pointer and Linked List in C https://github.com/skorks/c-linked-list/blob/master/linkedlist.c

//19/05/27//

Homework8 Assignment

Electric Computer Engineering Computer Major 

201524582 Jeong Hee Seok

clone hw8 and copy from codes hw7.

//19/05/29//(not commit)

conversion of array to Linked-list is completed and re-implement register, search, print for nodes

and error occured on delete.c

//19/06/01//

Modify delete.c and re-implement sort.c

Source Code Complete.

//=====================//

//report//

//19/06/02//

Upload Report

//Finish Homework//
