import javax.swing.JFrame;

public class BallBounced {
	public static void main(String[] args) {
		JFrame frame = new BallFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
//animate a bouncing ball
