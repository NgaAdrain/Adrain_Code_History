#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <iomanip>
#include <cstdlib>
using namespace std;

class std_Record{
	public :
		void inp_info(ifstream &input);
		void calculate();
		double return_total();
		void inp_grade(string g);
		void out_info(ofstream &output);
	private :
		string id;
		string name;
		string temp;
		int mid_score;
		int fin_score;
		int f_quiz;
		int s_quiz; 
		double total;
		string grade;
};

int main(){
	ifstream score_input("scores_input.txt");
	ofstream score_output("scores_output.txt");
	 if(score_input.fail()){
        cout << "Input file opening failed" <<endl;
        exit(1);
        }
	string temp;
	std_Record *list;
	double *list_grade;
	string grade[] = {"A+","A","A","B+","B+","B","B","C","D","F"};
	int std_num=0,count,count_2;
	double temp_score;
	while(getline(score_input,temp)){
		std_num++;
    }
    list = new std_Record[std_num];
    list_grade = new double[std_num];
	score_input.clear();
	score_input.seekg(0,ios::beg);
	for(count=0;count<std_num;count++){ //insert information
		list[count].inp_info(score_input);
		list[count].calculate();
		list_grade[count] = list[count].return_total();
	}
	for(count=0;count<std_num;count++){ //score sort
		for(count_2=count+1;count_2<std_num;count_2++){
			if(list_grade[count]<list_grade[count_2]){
				temp_score = list_grade[count];
				list_grade[count] = list_grade[count_2];
				list_grade[count_2] = temp_score;
			}
		}
	}
	for(count=0;count<std_num;count++){ //insert grade
		for(count_2=0;count_2<std_num;count_2++){
			if(list_grade[count]==list[count_2].return_total())
				list[count_2].inp_grade(grade[count]);
		}
	}
	for(count=0;count<std_num;count++)
		list[count].out_info(score_output);
	score_input.close();
	score_output.close();
	system("pause");
	return 0;
}

void std_Record::inp_info(ifstream &input){
	input >> id >> temp >> name;
	name = temp + " "  + name;
	input >> temp;
	mid_score = atoi(temp.c_str());
	input >> temp;
    fin_score = atoi(temp.c_str());
	input >> temp;
    f_quiz = atoi(temp.c_str());
	input >> temp;
    s_quiz = atoi(temp.c_str());
	//input >> mid_score >> fin_score;
	//input >> f_quiz >> s_quiz;
}

void std_Record::calculate(){
	total = (double) (mid_score*(0.3)) + (fin_score*(0.4)) + ((f_quiz+s_quiz)*1.5);
}

double std_Record::return_total(){
	return total;
}

void std_Record::inp_grade(string g){
	grade = g;
}

void std_Record::out_info(ofstream &output){
	output << id << "\t"; 
	output.setf(ios::left);
    output << setw(25) << name ;
	output << mid_score << "\t" << fin_score << "\t";
	output << f_quiz << "\t" << s_quiz << "\t";
	output << total << "\t";
	output << grade << endl;
}

