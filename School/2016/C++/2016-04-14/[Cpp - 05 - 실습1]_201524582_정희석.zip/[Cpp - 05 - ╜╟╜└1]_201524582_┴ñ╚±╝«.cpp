#include <iostream>
#include <cstring>
#define MAX_LINE 16
const int NUM_JUDGE=7;
const int NUM_PLAYER=3;
using namespace std;

class Pi_Sk_Score
{
	public: 
		void Score_Avg();
		void input_Score();
		void input_Name();
		double getAvg();
		char* getName();
	private:
		char name[MAX_LINE];
		int score[NUM_JUDGE];
		double Avg;
};

void sort(char* name[],double list[]);

int main()
{
	int count,count_2,x,temp_1;
	double score_Avg[NUM_PLAYER];
	char* nameList[NUM_PLAYER];
	Pi_Sk_Score Player[NUM_PLAYER];
	for(x=0;x<NUM_PLAYER;x++)
	{
		cout << "Player " << x+1 << ":" << endl;
		Player[x].input_Name();
		Player[x].input_Score();
		Player[x].Score_Avg();
		score_Avg[x] = Player[x].getAvg();
		nameList[x] = Player[x].getName();
		cout << endl;
	}
	
	cout << "Ranking " << endl;
	cout << "--------------------------------------------" << endl;
	sort(nameList,score_Avg);
    system("pause");
	return 0;
}

void Pi_Sk_Score::Score_Avg()
{
	int Min_Score,Max_Score,count_1,count_2,total=0;
	double Avg_Score;
	Min_Score = Max_Score = score[0];
	for(count_1=0;count_1<NUM_JUDGE;count_1++)
	{
		total += score[count_1];
		for(count_2=count_1+1;count_2<NUM_JUDGE;count_2++)
		{
			if(Max_Score<=score[count_2])
				Max_Score = score[count_2];
			if(Min_Score>=score[count_2])
				Min_Score = score[count_2];
		}
	}
	total = total - (Max_Score + Min_Score);
	Avg_Score = (double) total / (NUM_JUDGE-2);
	Avg = Avg_Score;
}
void Pi_Sk_Score::input_Name()
{
	cout << "Name : " ;
	fflush(stdin);
	cin >> name; 	
}
void Pi_Sk_Score::input_Score()
{
	int count;
	cout << "Input " << NUM_JUDGE << " scores : ";
	for (count=0;count<NUM_JUDGE;count++)
		cin >> score[count];
}

double Pi_Sk_Score::getAvg()
{
    return Avg;
}

char* Pi_Sk_Score::getName()
{
    char *p;
    p = name;
    return p;
}

void sort(char* name[],double list[])
{
     int x,y,size;
     double temp_avg;
     char *temp_name;
	 temp_name = (char*) malloc (MAX_LINE);
     for(x=0;x<NUM_PLAYER;x++)
    {
         for(y=x+1;y<NUM_PLAYER;y++)
         {
             if(list[x]<=list[y])
             {
                  temp_avg = list[x];
                  list[x] = list[y];
                  list[y] = temp_avg;
                  temp_name = name[x];
                  name[x] = name[y];
                  name[y] = temp_name;
             }
         }
	}
	cout.setf(ios::fixed);
	cout.setf(ios::showpoint);
	cout.precision(1);
    for(x=0;x<NUM_PLAYER;x++)
	{
        cout << x+1 << ". " ;                         
        size = strlen(name[x]);
		for(y=0;y<size;y++)
			cout << name[x][y];
		for(y=0;y<MAX_LINE-size;y++)
		cout << " ";
		cout << list[x] << endl;
    }
}

