package lab8Swing;

public class DialogUI {
	public static void main(String[] args) {
		ShowFrame frame = new ShowFrame("DialogUI");
	}
}
